const QuestionSchema = new mongoose.Schema({
  text: String,
  tags: [String],
  createdAt: Date
});
module.exports = mongoose.model('Question', QuestionSchema);
