const SessionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  questions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Question' }],
  answers: [{ question: String, answer: String, feedback: String, score: Number }],
  status: { type: String, default: 'active' },
  createdAt: Date
});
module.exports = mongoose.model('Session', SessionSchema);
