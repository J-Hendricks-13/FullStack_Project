const axios = require('axios');
const AI_URL = process.env.AI_SERVICE_URL;

router.post('/:id/answer', async (req,res) => {
  const { answer, questionText } = req.body;
  // save answer to DB
  const evalResp = await axios.post(`${AI_URL}/evaluate_answer`, { question: questionText, answer });
  // store feedback from evalResp.data
  res.json(evalResp.data);
});
