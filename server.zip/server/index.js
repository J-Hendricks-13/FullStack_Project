const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Route → forward to Python AI
app.get("/api/questions", async (req, res) => {
  try {
    const response = await fetch("http://localhost:8000/generate_questions");
    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI service failed" });
  }
});

app.listen(5000, () => console.log("Node server running on port 5000"));
