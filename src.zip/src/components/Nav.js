export default function Nav() {
  return (
    <nav>
      <a href="/">Dashboard</a> | 
      <a href="/mock">Mock Interview</a>
    </nav>
  );
}
