import React, { useEffect, useState } from "react";

function Dashboard() {
  const [questions, setQuestions] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/generate_questions")
      .then((res) => res.json())
      .then((data) => setQuestions(data.questions))
      .catch((err) => console.error("Fetch error:", err));
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      <ul>
        {questions.map((q, i) => (
          <li key={i}>{q}</li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
